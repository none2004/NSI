#lien : https://pub.phyks.me/sdz/sdz/interface-graphique-pygame-pour-python.html
#bibliotheque
import pygame
from pygame.locals import *

#lancement
pygame.init()

#fenetre
fenetre = pygame.display.set_mode((640, 480))

#fond
fond = pygame.image.load("background.jpg").convert()
fenetre.blit(fond, (0,0))

#personnage
perso = pygame.image.load("personnage.png").convert_alpha()
position_perso = perso.get_rect() #coord
fenetre.blit(perso, position_perso)

#rafraichissement
pygame.display.flip()

#variable ON
ON = 1
#boucle
pygame.key.set_repeat(400, 30)#fluidité
while ON:
    for event in pygame.event.get(): #parcours liste élément reçus
        if event.type == QUIT: #si un élement est quit
            ON = 0 #alors on arrète la boucle

        if event.type == KEYDOWN:
            if event.key == K_DOWN:
                position_perso = position_perso.move(0,10)
            if event.key == K_UP:
                position_perso = position_perso.move(0,-10)

    #image
    fenetre.blit(fond, (0,0))
    fenetre.blit(perso,position_perso)
    #actualisation
    pygame.display.flip()
